﻿

//(function () {

//    var proto = mini.DataGrid.prototype,
//        set = proto.set;

//    proto.set = function () {
//        set.apply(this, arguments);
//        if (!this._inited) {
//            this._init();
//        }
//    }

//    proto._init = function () {
//        this._inited = true;
//        
//        var menu = new ColumnsMenu(this);

//    }

//})();